WHITE RABBIT PREVIOUS-ARTICLES ARCHIVE UPGRADE

Extract this folder into the existing white_rabbit_researcher_mvp project root, then run install_upgrade.ps1.
The installer backs up replaced files, copies the upgrade, preserves the existing .env/API key, creates the archive directories, installs dependencies, and runs tests.
