$ErrorActionPreference = "Stop"

$UpgradeRoot = $PSScriptRoot
$ProjectRoot = Split-Path -Parent $UpgradeRoot
Set-Location $ProjectRoot

Write-Host "" 
Write-Host "WHITE RABBIT — PREVIOUS ARTICLES ARCHIVE UPGRADE" -ForegroundColor Cyan
Write-Host "Project root: $ProjectRoot"
Write-Host ""

if (-not (Test-Path (Join-Path $ProjectRoot "white_rabbit"))) {
    throw "This upgrade must be extracted directly inside the White Rabbit Researcher project root. Expected: $ProjectRoot\white_rabbit"
}

$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$BackupRoot = Join-Path $ProjectRoot "upgrade_backups\previous_articles_$Timestamp"
New-Item -ItemType Directory -Path $BackupRoot -Force | Out-Null

$ReplacementPaths = @(
    "white_rabbit\config.py",
    "white_rabbit\gemini_provider.py",
    "white_rabbit\cli.py",
    "white_rabbit\pipeline.py",
    "requirements.txt",
    ".env.example"
)

foreach ($Relative in $ReplacementPaths) {
    $Existing = Join-Path $ProjectRoot $Relative
    if (Test-Path $Existing) {
        $BackupPath = Join-Path $BackupRoot $Relative
        $BackupDir = Split-Path -Parent $BackupPath
        New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null
        Copy-Item $Existing $BackupPath -Force
    }
}

Write-Host "Backed up replaced files to: $BackupRoot" -ForegroundColor DarkGray

$FilesRoot = Join-Path $UpgradeRoot "files"
Get-ChildItem $FilesRoot -Recurse -File | ForEach-Object {
    $Relative = $_.FullName.Substring($FilesRoot.Length).TrimStart('\')
    $Destination = Join-Path $ProjectRoot $Relative
    $DestinationDir = Split-Path -Parent $Destination
    New-Item -ItemType Directory -Path $DestinationDir -Force | Out-Null
    Copy-Item $_.FullName $Destination -Force
}

# Required directory structure.
$Dirs = @(
    "research_library\previous_white_rabbit_articles\articles",
    "research_library\previous_white_rabbit_articles\imports\substack_exports",
    "research_library\previous_white_rabbit_articles\sync",
    "research_library\projects",
    "knowledge"
)
foreach ($Dir in $Dirs) {
    New-Item -ItemType Directory -Path (Join-Path $ProjectRoot $Dir) -Force | Out-Null
}

# Preserve the user's existing .env and only append missing settings.
$EnvPath = Join-Path $ProjectRoot ".env"
if (-not (Test-Path $EnvPath)) {
    Copy-Item (Join-Path $ProjectRoot ".env.example") $EnvPath
}
$EnvText = Get-Content $EnvPath -Raw
$Needed = [ordered]@{
    "WR_SUBSTACK_URL" = ""
    "WR_WHITE_RABBIT_SITEMAP_URL" = ""
    "WR_ARCHIVE_SYNC_BEFORE_RUN" = "true"
    "WR_ARCHIVE_PLAN_CHUNKS" = "10"
    "WR_ARCHIVE_WRITER_ARTICLES" = "6"
    "WR_ARCHIVE_REQUEST_DELAY_MS" = "120"
}
foreach ($Key in $Needed.Keys) {
    if ($EnvText -notmatch "(?m)^$([regex]::Escape($Key))=") {
        Add-Content -Path $EnvPath -Value "$Key=$($Needed[$Key])"
    }
}

# Ask once for the publication URL if it is still blank.
$EnvText = Get-Content $EnvPath -Raw
if ($EnvText -match "(?m)^WR_SUBSTACK_URL=\s*$") {
    Write-Host ""
    $Substack = Read-Host "Enter the White Rabbit publication URL (example: https://name.substack.com). Press Enter to configure later"
    if ($Substack) {
        $Lines = Get-Content $EnvPath
        $Lines = $Lines | ForEach-Object {
            if ($_ -match '^WR_SUBSTACK_URL=') { "WR_SUBSTACK_URL=$($Substack.TrimEnd('/'))" } else { $_ }
        }
        Set-Content -Path $EnvPath -Value $Lines -Encoding UTF8
    }
}

# Use the existing project venv when possible.
$Python = Join-Path $ProjectRoot ".venv\Scripts\python.exe"
if (-not (Test-Path $Python)) {
    if (Get-Command py -ErrorAction SilentlyContinue) {
        & py -m venv .venv
    } elseif (Get-Command python -ErrorAction SilentlyContinue) {
        & python -m venv .venv
    } else {
        throw "Python was not found and .venv does not exist. Configure the PyCharm interpreter first."
    }
}

Write-Host ""
Write-Host "Installing/updating Python dependencies..." -ForegroundColor Cyan
& $Python -m pip install --upgrade pip
& $Python -m pip install -r requirements.txt

Write-Host ""
Write-Host "Running tests..." -ForegroundColor Cyan
& $Python -m pytest -q
if ($LASTEXITCODE -ne 0) {
    throw "Tests failed. Existing files were backed up at $BackupRoot"
}

Write-Host ""
Write-Host "Upgrade installed successfully." -ForegroundColor Green
Write-Host "Archive root: research_library\previous_white_rabbit_articles"
Write-Host "Knowledge DB: knowledge\white_rabbit.db"
Write-Host "Project source folders: research_library\projects\<project_id>\sources"
Write-Host ""
Write-Host "Next commands:" -ForegroundColor Yellow
Write-Host "  .\.venv\Scripts\python.exe -m white_rabbit archive sync"
Write-Host "  .\.venv\Scripts\python.exe -m white_rabbit archive status"
Write-Host "  .\.venv\Scripts\python.exe -m white_rabbit archive sync --refresh   # optional full recheck"
Write-Host "  .\.venv\Scripts\python.exe -m white_rabbit doctor"
